package schoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchooSample183Application {

	public static void main(String[] args) {
		SpringApplication.run(SchooSample183Application.class, args);
	}

}
