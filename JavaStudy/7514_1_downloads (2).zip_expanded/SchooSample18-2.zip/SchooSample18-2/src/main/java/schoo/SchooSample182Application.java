package schoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchooSample182Application {

	public static void main(String[] args) {
		SpringApplication.run(SchooSample182Application.class, args);
	}

}
