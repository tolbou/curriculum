package schoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchooSample181Application {

	public static void main(String[] args) {
		SpringApplication.run(SchooSample181Application.class, args);
	}

}
