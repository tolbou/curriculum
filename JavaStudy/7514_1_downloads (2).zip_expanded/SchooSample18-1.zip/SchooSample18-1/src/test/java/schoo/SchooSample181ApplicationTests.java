package schoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchooSample181ApplicationTests {

	@Test
	void contextLoads() {
	}

}
